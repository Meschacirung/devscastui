package com.inventory;

public class Product {
    //Déclarations de champ d'instance
    //Stocker le nom du produit
    private String nomProduit;
    //Stocker le numéro de l'article
    private String numeroArticle;
    //Stocker le nombre d'unités en stock
    private int nombreStock;
    //Stocker le prix de chaque unité
    private float prixUnite;
    //Stocker l'etat  du statut du produit
    private boolean  active = true;

    //constructeur par defaut
    public Product() {
        nomProduit ="";
        numeroArticle = "";
        nombreStock = 0;
        prixUnite = 0.0f;
    }

    //constructeur avec 4 parametres
    public Product(String  nomProduit, String numeroArticle ,int nombreStock, float prixUnite){
        this.nomProduit= nomProduit;
        this.numeroArticle= numeroArticle;
        this.nombreStock = nombreStock;
        this.prixUnite= prixUnite;
    }

    public String getNomProduit() {
        // Retourner le nom du produit
        return nomProduit;
    }

    public void setNomProduit(String nomProduit) {
        //Modifier la valeur du nom du produit
        this.nomProduit = nomProduit;
    }

    public String getNumeroArticle() {
        // Retourner le numéro de l'article
        return numeroArticle;
    }

    public void setNumeroArticle(String numeroArticle) {
        //Modifier la valeur du numéro de l'article
        this.numeroArticle = numeroArticle;
    }

    public int getNombreStock() {
        //Retourner la valeur du nombre d'unités en stock
        return nombreStock;
    }

    public void setNombreStock(int nombreStock) {
        //Modifier la valeur du nombre d'unités en stock
        this.nombreStock = nombreStock;
    }

    public float getPrixUnite() {
        //Retourner la valeur du prix de chaque unité
        return prixUnite;
    }

    public void setPrixUnite(float prixUnite) {
        //Modifier la valeur du prix de chaque unité
        this.prixUnite = prixUnite;
    }

    public String toString (){
        //Definir le format de notre objet une fois convertir en chaine de charactere
        return "Numéro de l'article : " + getNumeroArticle() +
               "\nNom               : "+ getNomProduit() +
               "\nQuantité en stock : "  + getNombreStock() +
               "\nPrix              : "  + getPrixUnite()+
                "\nValeur du stock    : " + getInventoryValue() +
                "\nStatut du produit  : "+ ((active)?"Réapprovisionné" :"Non réapprovisionné") +"\n" ;
    }

    public boolean getActive() {
        //Retourner la valeur de l'etat  du statut du produit
        return active;
    }

    public void setActive(boolean active) {
        //Modifier la valeur de l'etat  du statut du produit
        this.active = active;
    }

    public  float getInventoryValue() {
        //Retourner  la valeur d'inventaire de chaque article
        return prixUnite*nombreStock;
    }
    public void addToInventory(int quantity){
        //ajoute une valeur à la quantite en stock
        nombreStock = nombreStock + quantity;
    }
    public void deductFromInventory(int quantity){
        //deduit une valeur à la quantite en stock
        nombreStock = nombreStock + quantity;
    }
}
