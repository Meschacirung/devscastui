package com.inventory;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ProductTester{
    public static void main(String[] args){

        Scanner in = new Scanner(System.in);
        int maxSize = getNumProducts(in);
        if (maxSize == 0){
            System.out.println("Aucun produit requis.");
        }else {
            Product[] products = new  Product[maxSize];
            addToInventory(products,in);
            displayInventory(products);
        }
        //Fermeture de l'objet Scanner
        in.close();
    }
    public static void displayInventory(Product[] products){
        for (Product product: products){
            System.out.println(product);
        }
    }

    public static void addToInventory(Product[] products,Scanner in){
        String tempNumber;
        String tempName;
        int  tempQty;
        float tempPrice;
        in.nextLine();
        for(int i = 0;i< products.length;i++) {
            System.out.println("Saisir le nom du produit : ");
            tempName = in.nextLine();
            System.out.println("Saisir la quantité du produit : ");
            tempQty = in.nextInt();
            try {
                System.out.println("Saisir le prix du produit : ");
                tempPrice = in.nextFloat();
            } catch (InputMismatchException e) {
                tempPrice = 0.0f;
            }
            in.nextLine();
            System.out.println("Saisir le numéro de l'article du produit : ");
            tempNumber = in.nextLine();
            products[i] = new Product(tempName, tempNumber, tempQty, tempPrice);
        }
    }
    public static int  getNumProducts(Scanner in){
        int maxSize =-1;
        try {
            do{
                System.out.println("Saisissez le nombre de produits à ajouter\n" +
                        " Saisissez 0 (zéro) si vous ne souhaitez pas ajouter de produits :");
                maxSize = in.nextInt();
                if(maxSize < 0){
                    System.out.println("Valeur incorrecte saisie");
                }else {
                    break;
                }
            }while (true);
        }catch (InputMismatchException i){
            System.out.println("Type de données incorrect saisi");
            in.nextLine();
        } catch (Exception e){
            e.printStackTrace();
            in.nextLine();
        }
        return  maxSize;
    }
    public static int getMenuOption(Scanner in){
        int menuChoix = -1;
        try{
            do {
                System.out.println("1. Afficher l'inventaire\n" +
                        "2. Ajouter une quantité de stock\n" +
                        "3. Déduire une quantité de stock\n" +
                        "4. Ne pas réapprovisionner le produit\n" +
                        "0. Quitter\n" +
                        "Veuillez saisir une option de menu :");
                menuChoix = in.nextInt();
                if(menuChoix > 4 || menuChoix < 0){
                    System.out.println("Valeur incorrecte saisie");
                }else{
                    break;
                }
            }while (true);
        }catch (InputMismatchException e){
            System.out.println("Type de données incorrect saisi");
            in.nextLine();
        }
        return menuChoix;
    }
    public static int getProductNumber(Product[] products, Scanner in){
        int productChoice = -1;
        try{
            do {
                System.out.println("Saisir l'indice du prodduit a selectionner : ");
                productChoice = in.nextInt();
                if(productChoice < 0 || productChoice > products.length){
                    System.out.println("Valeur incorrecte saisie");
                }else {
                    break;
                }
            }while (true);
        }catch (InputMismatchException i){
            System.out.println("Type de données incorrect saisi");
            in.nextLine();
        }
        System.out.println("La valeur de l'indice : "+ productChoice +"\nLe nom du produit : "+products[productChoice].getNomProduit());
        return  productChoice;
    }
    public static void addInventory(Product[] products, Scanner in){
        int productChoice = getProductNumber(products,in),updateValue = -1;
        try {
            do {
                System.out.println("Combien de produits voulez-vous ajouter ?");
                updateValue = in.nextInt();
                if(updateValue < 0){
                    System.out.println("Valeur incorrecte saisie");
                }else {
                    break;
                }
            }while (true);
        }catch (InputMismatchException i){
            System.out.println("Type de données incorrect saisi");
            in.nextLine();
        }
        products[productChoice].addToInventory(updateValue);
    }
    public static  void deductInventory (Product[] products,Scanner in){
        int productChoice = getProductNumber(products,in),updateValue = -1;
        try {
            do {
                System.out.println("Combien de produits voulez-vous ajouter ?");
                updateValue = in.nextInt();
                if(updateValue < 0){
                    System.out.println("Valeur incorrecte saisie");
                }else {
                    break;
                }
            }while (true);
        }catch (InputMismatchException i){
            System.out.println("Type de données incorrect saisi");
            in.nextLine();
        }
        products[productChoice].deductFromInventory(updateValue);
    }
    public  static  void discontinueInventory(Product[] products,Scanner in){
        int productChoice = getProductNumber(products,in);
        products[productChoice].setActive(false);
    }
    public static void executeMenuChoice(int menuChoix,Product[] products,Scanner in){
        System.out.println("Afficher la liste de produits\n" +
                "Ajouter une quantité de stock\n" +
                "Déduire une quantité de stock\n" +
                "Ne pas réapprovisionner le stoc\n");
    }
}

